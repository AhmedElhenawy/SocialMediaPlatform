package SocialMediaPlatform;

public class Like {
    private User liker;

    public Like(User liker) {
        this.liker = liker;
    }

    public User getLiker() {
        return liker;
    }
}
